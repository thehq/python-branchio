from __future__ import absolute_import
# BranchIo
# Copyright Headquarters HQ
# See LICENSE for details.

"""
Branch.io Api Library
"""
__version__ = '0.1.0'
__author__ = 'Eric Chapman'
__license__ = 'MIT'

from .client import Client
from .defines import *
